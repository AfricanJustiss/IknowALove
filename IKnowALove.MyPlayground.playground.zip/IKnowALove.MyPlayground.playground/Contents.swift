import UIKit

var str = "Hello, playground"
let A = 1
let B = 1
if A+B == 2 {
print("When I look into your eyes, It keeps me up at night, I can't explain the pride, But now, I realize")
}

let C = 1
let D = 1
if C+D == 2 {
    print("I know a love, nothin' compares to you, Somethin' so real, it make me feel brand new")
}

let E = 1
let F = 1
if E+F == 2 {
print("Wanna be the one to catch you when you fall, I'm gon' be here, that's forever, that's for sure")
}

let G = 1
let H = 1
if G+H == 2 {
print("'Cause I know a love that make a man feel good, I know a love I never knew I could")
}

let I = 1
let J = 1
if I+J == 2 {
    print("I'm so thankful, you're a blessin' from above, So amazin', now I know a better love")
}
let K = 1
let L = 1
if K+L == 2 {
    print("No better feelin' than the one like this (no), I thought I had it all, but I didn't (no)")
}
let M = 1
let N = 1
if M+N == 2 {
    print("It makes me wonder (oh yeah), Where you've been all my life")
}
let O = 1
let P = 1
if O+P == 2 {
    print("And it feels so familiar Damn, I know that this is the realest love, When I look into your eyes, It keeps me up at night")
}
let Q = 1
let R = 1
if Q+R == 2 {
    print("I can't explain the pride But now, I realize I know a love, nothin' compares to you")
}
let S = 1
let T = 1
if S+T == 2 {
    print("Somethin' so real, it make me feel brand new (wanna be, yeah), Wanna be the one to catch you when you fall (when you fall)")
}
let U = 1
let V = 1
if U+V == 2 {
    print("I'm gon' be here, that's forever, that's for sure ('cause I know a love that), 'Cause I know a love that make a man feel good (oh yeah), I know a love I never knew I could (oh)")
}
let W = 1
let X = 1
if W+X == 2 {
     
    print("I'm so thankful, you're a blessin' from above (thank you Lord), So amazin', now I know a better love, I been needin' some substance, I been lookin' for somethin', I couldn't find it in nothin', oh")
}
let Y = 1
let Z = 1
if Y+Z == 2 {
    print("'Til I held you in my arms (oh, now I know a love), I know a love, nothin' compares to you (don't compare)Somethin' so real, it make me feel brand new (wanna be), Wanna be the one to catch you when you fall (oh, woah),I'm gon' be here, that's forever, that's for sure (I know a love), 'Cause I know a love that make a man feel good (so good), I know a love I never knew I could (woah), I'm so thankful, you're a blessin' from above (from above), So amazin', now I know a better love (know a love)")
}

// The above is an example of rule setting and execution within the boundaries of those roles within the swift programming language. As you can see, the above code can be broken down into 3 segments. Variables, which hold information, make it unchanging, and is taken consideration when a task needs to be completed. Next, you see the "If" initiation statement. This statement is what establishes the rule, or the simply put how the previously established information is to be used. In this case, the if statement states that Y, which represents the number 1, is to be added to Z, which is representing the number 1 as well. We see that one and one is 2, so we are sure to establish that if this is the case, and it is, then the program will proceed to print the desired text, or the song verse in this case. If we change it to, say, Y+Z == "3" instead of 2, the program will then understand that it should not print the text, as the rule is no longer being followed, due to the establised variables being 1 + 1, which is 2, not 3.
